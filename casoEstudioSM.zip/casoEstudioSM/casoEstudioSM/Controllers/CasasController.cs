﻿using casoEstudioSM.Models;
using Dapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;

namespace casoEstudioSM.Controllers
{
    public class CasasController : Controller
    {
        private readonly IConfiguration _conf;
        public CasasController(IConfiguration conf)
        {
            _conf = conf;
        }
  


        [HttpGet]
        public IActionResult RegistroAlquiler()
        {
            using (var context = new SqlConnection(_conf.GetSection("ConnectionStrings:DefaultConnection").Value))
            {


                // Ejecutar el procedimiento almacenado para obtener las casas disponibles
                var casasDisponibles = context.Query<CasasModel>("ConsultarCasasDisponibles").ToList();

                // Guardar las casas disponibles en ViewBag
                ViewBag.CasasDisponibles = casasDisponibles.Select(c => new SelectListItem
                {
                    Value = c.IdCasa.ToString(),
                    Text = c.DescripcionCasa
                }).ToList();

                return View();
            }
        }





        [HttpPost]

        public IActionResult RegistroAlquiler(CasasModel model)
        {

            using (var context = new SqlConnection(_conf.GetSection("ConnectionStrings:DefaultConnection").Value))



            {
                var respuesta = new Respuesta();
                var result = context.Execute("AlquilarCasa", new { model.IdCasa, model.UsuarioAlquiler });
                if (result > 0)
                {
                    respuesta.codigo = 0;
                    return RedirectToAction("Index", "Home");

                }
                else
                {
                    respuesta.codigo = -1;
                    respuesta.Mensaje = "Su informacion no se ha registrado correctamente";
                    return View();

                }


            }
        }


        [HttpGet]

        public IActionResult ConsultarCasasDisponibles()
        {
            using (var context = new SqlConnection(_conf.GetSection("ConnectionStrings:DefaultConnection").Value))
            {
                var respuesta = new Respuesta();
                var result = context.Query<CasasModel>("ConsultarCasasDisponibles", new { });

                if (result.Any())
                {
                    respuesta.codigo = 0;
                    respuesta.Contenido = result;
                }
                else
                {
                    respuesta.codigo = -1;
                    respuesta.Mensaje = "No hay Compras pendientes en este momento";
                }

                return Ok(respuesta);
            }
        }

        [HttpGet]
        public IActionResult ObtenerCasasDisponibles()
        {
            using (var context = new SqlConnection(_conf.GetSection("ConnectionStrings:DefaultConnection").Value))
            {
                var casas = context.Query<CasasModel>("ConsultarCasasDisponibles").ToList();

                if (casas.Any())
                {
                    return Json(casas.Select(c => new
                    {
                        id_Casa = c.IdCasa,
                        descripcion = c.DescripcionCasa,
                        precio = c.PrecioCasa
                    }));
                }

                return Json(new List<object>()); // Retorna una lista vacía si no hay resultados
            }
        }
        [HttpGet]
        public IActionResult ConsultaCasas()
        {
            using (var context = new SqlConnection(_conf.GetSection("ConnectionStrings:DefaultConnection").Value))
            {
                var respuesta = new Respuesta();
                var result = context.Query<CasasModel>("ConsultarCasas", new { });

                if (result.Any())
                {
                    // Aquí, en lugar de retornar un JSON, pasamos los datos a la vista
                    respuesta.codigo = 0;
                    respuesta.Contenido = result;

                    // Pasar los datos a la vista
                    return View(result); // Pasamos directamente los datos a la vista
                }
                else
                {
                    // Si no hay datos, pasamos un mensaje de error
                    respuesta.codigo = -1;
                    respuesta.Mensaje = "No hay casas disponibles en este momento";

                    // Pasar la respuesta con un mensaje
                    ViewBag.Mensaje = respuesta.Mensaje;
                    return View(new List<CasasModel>()); // Retorna una lista vacía si no hay resultados
                }
            }
        }
    }
}

    
