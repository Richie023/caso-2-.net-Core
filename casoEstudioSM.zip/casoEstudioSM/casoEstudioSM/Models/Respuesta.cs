﻿namespace casoEstudioSM.Models
{
    public class Respuesta
    {
        public int codigo { get; set; }
        public string Mensaje { get; set; } = string.Empty;
        public object? Contenido { get; set; }
    }
}
